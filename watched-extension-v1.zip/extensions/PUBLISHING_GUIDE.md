# How to Publish to the Chrome Web Store

Publishing your "Watched" extension allows anyone to install it easily and ensures automatic updates.

## 1. Prepare Your Package
You need a clean `.zip` file of just your extension code.

1.  **Open Terminal** in your project folder (`watchlist`).
2.  **Zip the `extensions` folder:**
    ```bash
    zip -r watched-extension-v1.zip extensions
    ```
    *(Ensure you are zipping the `extensions` folder, NOT the whole project)*

## 2. Create a Developer Account
1.  Go to the [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/developer/dashboard).
2.  Sign in with the Google Account you want to own the extension.
3.  **Register:** You must pay a **one-time $5 fee** to verify your account.

## 3. Upload Your Item
1.  Click **+ New Item**.
2.  Drag and drop your `watched-extension-v1.zip` file.
3.  The Store will read your `manifest.json` and start the listing.

## 4. Fill Out the Listing
You need to provide details for the public page:

*   **Description:** Explain what it does.
    > "Automatically tracks the movies and TV shows you find on Google Search. Connects to your Watched Dashboard to build your viewing history."
*   **Category:** Select **Start Page** or **Search Tools** (or *Entertainment*).
*   **Language:** English.
*   **Graphic Assets:**
    *   **Icon:** `extensions/images/icon128.png` (Required).
    *   **Store Icon:** `extensions/images/icon128.png` (You can upload this for all required sizes).
    *   **Screenshot:** `extensions/images/store_screenshot_mockup.png` (or take a real screenshot of your search page).
    *   **Marquee:** `extensions/images/marquee_promo.png` (440x280).

## 5. Privacy Practices (Critical)
Since your `manifest.json` asks for `host_permissions` ("watched.onrender.com") and `cookies` via script injection, you must declare this:

1.  **Privacy Policy URL:** You need a link. You can host a simple MD page on your Render site or GitHub Pages.
2.  **Permissions Justification:**
    *   **ActiveTab/Scripting:** "To identify movie titles on Google Search results."
    *   **Storage/Cookies:** "To authenticate with the user's Watched account to save their history."

## 6. Submit for Review
1.  Click **Submit for Review**.
2.  **Wait:** Reviews typically take **24-48 hours**.
3.  Once approved, you will get a link to your extension on the store!

## Verification & Updates
*   **To Update:** Just increment the `version` in `manifest.json` (e.g., `"1.1"`), re-zip, and upload the new zip to the dashboard. Users get updated automatically within hours.
